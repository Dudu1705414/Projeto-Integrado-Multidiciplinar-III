/* ═══════════════════════════════════════════
   DojoDev — Toast / Feedback System
   Uses Tailwind CSS classes for styling
   ═══════════════════════════════════════════ */

(function () {
  // Inject container once
  function getContainer() {
    let c = document.getElementById('toast-container');
    if (!c) {
      c = document.createElement('div');
      c.id = 'toast-container';
      c.className = 'fixed top-5 right-5 z-[9999] flex flex-col gap-3 pointer-events-none';
      document.body.appendChild(c);
    }
    return c;
  }

  const ICONS = {
    success: '✅',
    error:   '❌',
    info:    'ℹ️',
    warning: '⚠️',
    xp:      '⭐',
  };

  const COLORS = {
    success: 'bg-emerald-900/90 border border-emerald-500/40 text-emerald-200',
    error:   'bg-red-900/90 border border-red-500/40 text-red-200',
    info:    'bg-indigo-900/90 border border-indigo-500/40 text-indigo-200',
    warning: 'bg-yellow-900/90 border border-yellow-500/40 text-yellow-200',
    xp:      'bg-[#0d1a00]/90 border border-[#b4ff3e]/40 text-[#b4ff3e]',
  };

  /**
   * Show a toast notification
   * @param {string} message  - Main message
   * @param {'success'|'error'|'info'|'warning'|'xp'} type
   * @param {string}  [sub]   - Optional subtitle
   * @param {number}  [duration=3500] - ms before auto-dismiss
   */
  window.toast = function (message, type = 'info', sub = '', duration = 3500) {
    const container = getContainer();
    const t = document.createElement('div');
    t.className = [
      'pointer-events-auto flex items-start gap-3 px-4 py-3 rounded-xl shadow-2xl',
      'backdrop-blur-sm min-w-[280px] max-w-[360px]',
      'translate-x-0 transition-all duration-300',
      COLORS[type] || COLORS.info,
    ].join(' ');

    t.innerHTML = `
      <span class="text-xl mt-0.5 flex-shrink-0">${ICONS[type] || 'ℹ️'}</span>
      <div class="flex-1 min-w-0">
        <p class="font-semibold text-sm leading-snug" style="font-family:'Syne',sans-serif">${message}</p>
        ${sub ? `<p class="text-xs mt-0.5 opacity-70">${sub}</p>` : ''}
      </div>
      <button class="flex-shrink-0 opacity-50 hover:opacity-100 transition-opacity text-lg leading-none mt-0.5" onclick="this.parentElement.remove()">×</button>
    `;

    // Animate in
    t.style.opacity = '0';
    t.style.transform = 'translateX(40px)';
    container.appendChild(t);
    requestAnimationFrame(() => {
      t.style.transition = 'all 0.3s ease';
      t.style.opacity = '1';
      t.style.transform = 'translateX(0)';
    });

    // Auto-remove
    setTimeout(() => {
      t.style.opacity = '0';
      t.style.transform = 'translateX(40px)';
      setTimeout(() => t.remove(), 300);
    }, duration);
  };

  // Convenience wrappers
  window.toastSuccess = (msg, sub, d) => window.toast(msg, 'success', sub, d);
  window.toastError   = (msg, sub, d) => window.toast(msg, 'error',   sub, d);
  window.toastInfo    = (msg, sub, d) => window.toast(msg, 'info',    sub, d);
  window.toastWarning = (msg, sub, d) => window.toast(msg, 'warning', sub, d);
  window.toastXP      = (amount)       => window.toast(`+${amount} XP ganhos!`, 'xp', 'Continue assim, ninja! 🥷', 3000);
})();
