# 🥷 DojoDev - Aprenda Programação Brincando

Uma plataforma gamificada de aprendizado de programação com tema ninja/dojo, totalmente responsiva e funcional em mobile.

## ✨ Características

- **Tema Dark Ninja/Dojo**: Design moderno com cores roxo, verde e vermelho
- **100% Responsivo**: Funciona perfeitamente em desktop, tablet e mobile
- **3 Perfis de Usuário**:
  - 👨‍🎓 **Aluno**: Dashboard de aprendizado com trilhas e lições
  - 👨‍🏫 **Professor**: Painel para criar e gerenciar trilhas
  - ⚙️ **Admin**: Dashboard administrativo com métricas

- **Gamificação Completa**:
  - Sistema de XP e níveis
  - Streaks diários
  - Progresso visual
  - Ranking de alunos

- **Trilhas de Aprendizado**:
  - JavaScript Iniciante
  - HTML & CSS
  - Python Iniciante

- **Tipos de Lições**:
  - Quiz de múltipla escolha
  - Desafios de código
  - Leitura de código

- **Chat Sensei**: Assistente interativo para tirar dúvidas
- **Interface Intuitiva**: Fácil de usar e navegar

## 🚀 Como Rodar Localmente

### Opção 1: Python (Recomendado)

```bash
# Navegue até a pasta do projeto
cd dojodev-v2

# Inicie o servidor
python3 -m http.server 8000
```

Depois acesse: **http://localhost:8000**

### Opção 2: Node.js

```bash
# Instale o http-server globalmente (se não tiver)
npm install -g http-server

# Navegue até a pasta
cd dojodev-v2

# Inicie o servidor
http-server -p 8000
```

Depois acesse: **http://localhost:8000**

### Opção 3: Live Server (VS Code)

1. Instale a extensão "Live Server" no VS Code
2. Clique com botão direito em `index.html`
3. Selecione "Open with Live Server"

### Opção 4: Abrir Direto no Navegador

Simplesmente abra o arquivo `index.html` no seu navegador (sem servidor):

```bash
# No Windows
start index.html

# No macOS
open index.html

# No Linux
xdg-open index.html
```

## 📁 Estrutura de Arquivos

```
dojodev-v2/
├── index.html          # Página de cadastro
├── login.html          # Página de login
├── dojo.html           # Dashboard do aluno
├── jornada.html        # Trilhas de aprendizado
├── missoes.html        # Missões/desafios
├── sensei.html         # Chat com assistente
├── perfil.html         # Perfil do aluno
├── nivel.html          # Página de níveis
├── faixa.html          # Página de faixas
├── professor.html      # Painel do professor
├── admin.html          # Painel do admin
├── style.css           # Estilos (tema dark, responsivo)
├── toast.js            # Sistema de notificações
├── ninja_login.webp    # Imagem ninja (login)
├── ninja_cadastro.webp # Imagem ninja (cadastro)
└── README.md           # Este arquivo
```

## 🎮 Como Usar

### 1. **Primeira Vez - Cadastro**

1. Abra a aplicação (você será redirecionado para cadastro)
2. Preencha os dados:
   - Nome completo
   - Idade (13-120 anos)
   - Gênero
   - E-mail
   - Senha (mín. 6 caracteres)
3. Clique em "Cadastrar"

### 2. **Login**

1. Clique em "Fazer login"
2. Insira e-mail e senha
3. **Selecione o tipo de conta**:
   - **Aluno**: Acesso ao dashboard de aprendizado
   - **Professor**: Acesso ao painel de professor
   - **Admin**: Acesso ao painel administrativo
4. Clique em "Entrar agora"

Ou clique em "Entrar como convidado" para testar sem criar conta.

### 3. **Dashboard do Aluno**

- Veja seu XP, nível e streak
- Escolha uma trilha de aprendizado
- Complete as lições (quizzes e desafios)
- Ganhe XP e suba de nível
- Use o Sensei para tirar dúvidas

### 4. **Painel do Professor**

- Veja estatísticas de suas trilhas
- Crie novas trilhas
- Gerenciar alunos inscritos
- Visualize relatórios de desempenho

### 5. **Painel do Admin**

- Dashboard com métricas gerais
- Gerenciar usuários
- Gerenciar trilhas
- Visualizar relatórios
- Configurar plataforma

## 🎨 Customização

### Mudar Cores (em `style.css`)

```css
:root {
  --bg:        #000000;      /* Fundo preto */
  --surface:   #14141e;      /* Superfícies */
  --purple:    #7c6af0;      /* Roxo principal */
  --green:     #b4ff3e;      /* Verde neon */
  --red:       #ff4d4d;      /* Vermelho */
  /* ... mais cores */
}
```

### Adicionar Novas Trilhas (em `jornada.html`)

Procure por `const MODULES = [` e adicione:

```javascript
{
  id: 4,
  title: 'Sua Nova Trilha',
  lang: 'Linguagem',
  icon: '🎯',
  desc: 'Descrição da trilha',
  difficulty: 'beginner',
  lessons: [
    { id: 13, title: 'Lição 1', type: 'quiz', xp: 10 },
    // ... mais lições
  ],
}
```

### Adicionar Novos Quizzes (em `jornada.html`)

Procure por `const QUIZZES = {` e adicione:

```javascript
13: {
  question: 'Sua pergunta?',
  options: ['Opção A', 'Opção B', 'Opção C', 'Opção D'],
  correct: 0, // índice da resposta correta
  explanation: 'Explicação da resposta',
}
```

## 📱 Responsividade

O projeto é totalmente responsivo com breakpoints em:

- **Desktop**: 1200px+
- **Tablet**: 768px - 1199px
- **Mobile**: até 767px
- **Small Mobile**: até 480px
- **Landscape**: Otimizado para modo paisagem

Todos os elementos se adaptam automaticamente!

## 🔧 Tecnologias

- **HTML5**: Estrutura semântica
- **CSS3**: Estilos modernos, flexbox, grid, media queries
- **JavaScript Vanilla**: Sem dependências externas
- **LocalStorage**: Persistência de dados no navegador
- **Tailwind CSS**: Utilitários CSS (via CDN)

## 💾 Dados Salvos Localmente

O projeto salva automaticamente no navegador:

- Nome do usuário
- E-mail e senha
- Tipo de conta (aluno/professor/admin)
- XP e nível
- Lições completadas
- Histórico de chat
- Faixa/belt atual

**Nota**: Os dados são salvos em `localStorage` do navegador. Se limpar o cache/cookies, os dados serão perdidos.

## 🎓 Exemplos de Login

### Aluno
- E-mail: `aluno@example.com`
- Senha: `123456`
- Tipo: **Aluno**

### Professor
- E-mail: `professor@example.com`
- Senha: `123456`
- Tipo: **Professor**

### Admin
- E-mail: `admin@example.com`
- Senha: `123456`
- Tipo: **Admin**

Ou use o botão "Entrar como convidado" para testar sem criar conta!

## 🚀 Próximas Melhorias

- [ ] Backend com banco de dados
- [ ] Autenticação real
- [ ] Sistema de rankings em tempo real
- [ ] Mais linguagens de programação
- [ ] Certificados ao completar trilhas
- [ ] Integração com IA real para Sensei
- [ ] Sistema de comentários nas lições
- [ ] Desafios colaborativos
- [ ] Notificações push
- [ ] Modo offline

## 📝 Licença

Este projeto é de código aberto e pode ser usado livremente.

## 🤝 Contribuições

Sinta-se à vontade para:
- Reportar bugs
- Sugerir novas funcionalidades
- Melhorar o design
- Adicionar novas trilhas

## 👨‍💻 Desenvolvido com ❤️

**DojoDev** - Aprenda Programação Brincando!

---

## ❓ Dúvidas Frequentes

**P: Posso usar em produção?**
R: Este é um projeto de demonstração. Para produção, seria necessário adicionar um backend com banco de dados real.

**P: Os dados são salvos na nuvem?**
R: Não, todos os dados são salvos localmente no seu navegador usando `localStorage`.

**P: Funciona offline?**
R: Sim! Uma vez carregado, funciona completamente offline.

**P: Posso customizar as trilhas?**
R: Sim! Edite o arquivo `jornada.html` e adicione suas próprias trilhas e lições.

**P: Como adiciono mais linguagens?**
R: Edite os arrays `MODULES` e `QUIZZES` nos arquivos HTML correspondentes.

---

**Comece sua jornada ninja agora! 🥷**
