# 📱 DojoDev - Guia para Rodar no Mobile

Instruções completas para acessar o DojoDev no seu celular (Android ou iOS).

## 🚀 Opção 1: Servidor Local na Rede (Recomendado)

A melhor forma é rodar um servidor no seu PC e acessar pelo celular na mesma rede WiFi.

### Passo 1: Descubra o IP do seu PC

**Windows:**
```bash
ipconfig
```
Procure por "IPv4 Address" (algo como `192.168.1.100`)

**macOS/Linux:**
```bash
ifconfig
```
Procure por `inet` (algo como `192.168.1.100`)

### Passo 2: Inicie o Servidor

**Python (Recomendado):**
```bash
cd dojodev-v2
python3 -m http.server 8000
```

**Node.js:**
```bash
cd dojodev-v2
npx http-server -p 8000
```

### Passo 3: Acesse no Celular

1. Conecte seu celular na **mesma rede WiFi** do PC
2. Abra o navegador do celular (Chrome, Safari, Firefox, etc)
3. Digite: `http://SEU_IP:8000`
   - Exemplo: `http://192.168.1.100:8000`

**Pronto! O DojoDev vai abrir no seu celular!** 🎉

---

## 🌐 Opção 2: Ngrok (Acesso de Qualquer Lugar)

Se quiser acessar de fora da rede WiFi, use o Ngrok.

### Passo 1: Instale o Ngrok

Baixe em: https://ngrok.com/download

### Passo 2: Inicie o Servidor Localmente

```bash
cd dojodev-v2
python3 -m http.server 8000
```

### Passo 3: Exponha com Ngrok

```bash
ngrok http 8000
```

Você verá algo como:
```
Forwarding    https://abc123def456.ngrok.io -> http://localhost:8000
```

### Passo 4: Acesse no Celular

Abra no navegador do celular:
```
https://abc123def456.ngrok.io
```

**Funciona de qualquer lugar do mundo!** 🌍

---

## 📲 Opção 3: GitHub Pages (Estático)

Se quiser hospedar gratuitamente, use GitHub Pages.

### Passo 1: Crie um Repositório no GitHub

1. Vá para https://github.com/new
2. Crie um repositório chamado `dojodev`

### Passo 2: Faça Upload dos Arquivos

```bash
cd dojodev-v2
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/dojodev.git
git push -u origin main
```

### Passo 3: Ative GitHub Pages

1. Vá para Settings do repositório
2. Clique em "Pages"
3. Selecione "main" branch
4. Clique em "Save"

### Passo 4: Acesse no Celular

Seu site estará em:
```
https://SEU_USUARIO.github.io/dojodev
```

**Funciona em qualquer celular conectado à internet!** 📱

---

## 🔗 Opção 4: Vercel (Recomendado para Produção)

Hospedagem gratuita e rápida.

### Passo 1: Instale Vercel CLI

```bash
npm install -g vercel
```

### Passo 2: Deploy

```bash
cd dojodev-v2
vercel
```

Siga as instruções na tela.

### Passo 3: Acesse no Celular

Você receberá um link como:
```
https://dojodev-abc123.vercel.app
```

---

## 🍎 Opção 5: Criar App iOS (Sem Código)

Transforme em um app nativo do iOS.

### Usando Capacitor:

```bash
npm install -g @capacitor/cli
cd dojodev-v2
npx cap init
npx cap add ios
npx cap open ios
```

Depois compile no Xcode.

---

## 🤖 Opção 6: Criar App Android (Sem Código)

Transforme em um app nativo do Android.

### Usando Capacitor:

```bash
npm install -g @capacitor/cli
cd dojodev-v2
npx cap init
npx cap add android
npx cap open android
```

Depois compile no Android Studio.

---

## ⚡ Dicas de Performance no Mobile

### 1. **Modo Offline**
O DojoDev funciona offline! Uma vez carregado, você pode usar sem internet.

### 2. **Adicione à Home Screen**

**iPhone (Safari):**
1. Abra o site
2. Clique em "Compartilhar"
3. Selecione "Adicionar à Tela de Início"

**Android (Chrome):**
1. Abra o site
2. Clique no menu (⋮)
3. Selecione "Instalar app"

Depois acessa como um app normal!

### 3. **Modo PWA (Progressive Web App)**

O site já é PWA! Funciona como app:
- Ícone na home screen
- Funciona offline
- Carregamento rápido
- Sem precisar de app store

---

## 🔧 Troubleshooting

### "Não consigo conectar ao servidor"

**Solução:**
1. Certifique-se que PC e celular estão na **mesma rede WiFi**
2. Verifique o firewall do PC
3. Tente desativar VPN
4. Use `0.0.0.0` em vez de IP específico:
   ```bash
   python3 -m http.server 8000 --bind 0.0.0.0
   ```

### "A página carrega lentamente"

**Solução:**
1. Verifique a conexão WiFi
2. Feche abas desnecessárias
3. Limpe cache do navegador
4. Tente em outro navegador

### "Dados não salvam"

**Solução:**
1. Verifique se o navegador permite localStorage
2. Tente em modo normal (não privado)
3. Limpe cookies e tente novamente

### "Imagens não carregam"

**Solução:**
1. Verifique conexão de internet
2. Recarregue a página
3. Tente em outro navegador

---

## 📊 Comparação de Métodos

| Método | Facilidade | Velocidade | Acesso Remoto | Custo |
|--------|-----------|-----------|---------------|-------|
| Servidor Local | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ❌ | Grátis |
| Ngrok | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ✅ | Grátis |
| GitHub Pages | ⭐⭐⭐ | ⭐⭐⭐ | ✅ | Grátis |
| Vercel | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ | Grátis |
| App iOS | ⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ | Grátis |
| App Android | ⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ | Grátis |

---

## 🎯 Recomendação

**Para desenvolvimento rápido:** Servidor Local (Opção 1)
**Para compartilhar com amigos:** Ngrok (Opção 2)
**Para produção:** Vercel (Opção 4)
**Para app nativo:** Capacitor (Opção 5/6)

---

## 📱 Testado em

- ✅ iPhone (Safari)
- ✅ Android (Chrome)
- ✅ Android (Firefox)
- ✅ iPad (Safari)
- ✅ Samsung Galaxy
- ✅ Xiaomi
- ✅ Todos os tamanhos de tela

---

## 🚀 Quick Start (Mais Rápido)

Se quer rodar agora mesmo:

```bash
# 1. Extraia o ZIP
unzip dojodev-v2.zip
cd dojodev-v2

# 2. Inicie servidor
python3 -m http.server 8000

# 3. No celular, acesse
http://SEU_IP_DO_PC:8000
```

**Pronto! Está rodando no seu celular!** 📱🥷

---

**Aproveite o DojoDev no seu mobile! 🎉**
